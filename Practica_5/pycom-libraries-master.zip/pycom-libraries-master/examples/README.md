## Overview
This folder contains several samples that demonstrate various Pycom board functions. The samples are currently provided with the boot.py file to copy directly on the board.

## Installation

This section explains the individual steps to run example application using the Pymakr.
Steps:
 - Open Pymakr
 - In the menu, go to Project > New
 - Fill project name, select example folder for Project directory and select project type "Python project"
 - On popup add existing files to the project.
