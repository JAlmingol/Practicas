
# Pymesh mobile application

For demonstrating **Pymesh** features, a mobile application was created.

It is available for both Android and iOS platforms.

## Android application

It is available as `.apk` packet in this directory.

# iOS mobile application

Pymesh mobile application is released currently (v0.) as Beta testing, on Apple TestFlight (to be installed for free from App Store).

Pymesh app can be added afterwards, using the link: https://testflight.apple.com/join/PIxwbTKp

Requirements: iOS minimum version v12.1
